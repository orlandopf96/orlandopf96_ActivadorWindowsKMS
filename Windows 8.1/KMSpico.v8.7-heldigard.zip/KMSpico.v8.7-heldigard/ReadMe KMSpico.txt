KMSpico

Use any of the Editions: Install, OEM , Only Service or Portable.
You dont need to use more than 1 edition,
one edition is enough, I recommend the more complete: Install Edition.
(No necesitas usar m�s de una edici�n,
una edici�n es suficiente, te recomiendo la m�s completa: edici�n de instalar.)