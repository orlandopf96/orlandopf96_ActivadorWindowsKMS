Important: If you like MS Windows and MS Office please buy legal and original
			this program help to test this products, but recommend you buy legal from creators (M$ Corp).
			I did this for fun, and now I am done with this. 
			Working in W8 and Office 2013 fresh install and VOLUMEN LICENSE editions.
			Ja mata ne, Farewell, Hejd�, Ciao, Aloha, Zegnaj, Doei

KMSpico v8.7 OEM Edition. (Silent Install)

- Requirements: .NET 4.0 or Windows 8/2012.
- Activate: Windows Vista Business/N/Enterprise/N
			Windows 7
			Windows 8
			Windows (8.1 Preview) 
			Office 2010/2013 
			Windows Server 2008/2008R2/2012

1. Copy the $OEM$ folder inside of the Windows ISO image (inside of sources folder).
2. Install the O.S. from the iso modified.
3. Done.

Based off of open source code KMSEmulator of jm287.

Recommendations Optional:

- Make exceptions to Directory %ProgramFiles%\KMSpico\*.exe in Antivirus or Defender.

How This Program Works:

1. It install automatically KMSpico v8.7 Install Edition at the end of the Windows 8 installation.

Change Log:
- Support for all Windows 7 Editions. New way to convert any Retail edition to VL.(Finally)
- Support for Windows Vista. (Finally)
- Support for all Office 2013 Editions. (Finally)
- Add Office Backup.


+ L E G A L +

First of all you should know that I do NOT release these cracks
so that you "the end-user" can benefit from it in the term of
using software or any other of these releases without buying
the required licenses. heldigard however believe that everyone
should have the option to test and backup their program and be
able to run it without any problems.

Further I do NOT in any way condone the spreading of this
crack, in other words I do NOT spread the releases to any
websites, P2P networks or any other public available location
and I urge that this releases should not be spread like that
at all.

I -heldigard- has nothing to do with the distribution of these
cracks, it is all done by third parties. As such, and
according to the laws where the individuals of heldigard reside,
it is not my responsibility what others decides to do with
these releases. However, let it be said quite clearly;

"I DO NOT in any way condone the selling or redistribution
of these cracks, this was NEVER my intention."

heldigard does NOT take any responsibility of computer-loss
or any data-errors that may occur from using these cracks.
Keep in mind that you are using a third party solution to
something we did not develop in the first place.

Do note that the usage of these cracks are legal in most
countries outside the United States, IF and ONLY IF you own a
full copy of the program - then you may use these cracks
for backup purposes, and only that. It remains to be seen how
affected you are of the End User License Agreements (EULAs).
They can't supersede domestic laws, remember that.

According to the "DMCA ACT" in the Unites States, you have no
rights to circumvent a copy protection. Beware, they will
punish you harder than if you stole the shrinkwrapped software
in a mall. Though heldigard's base of operation does not reside
in the Unites States, and thus I am NOT bound to the
US legislations like:

* No Electronic Theft Act
* Digital Millenium Copyright Act
* The Patriot Act
* &lt;other US legislations&gt;

You should ALWAYS buy the software that you do use, or find
suitable Open Source replacements (as there are loads), I do!

By using these cracks you automatically agree
to the written agreement above, and thus the responsibility
regarding whatever you are affected by any EULAs is
with YOU and YOU only.

+ G R E E T S +

NOSFERATI, JM287, HOTBIRD64, DEAGLES, MIKMIK38, QAD, CODYQX4, XINSO, 
CERBERUS8855, HUI.

FORUMS.MYDIGITALLIFE.INFO
WWW.NSANEFORUMS.COM
NOTFAKE.ME
WWW.INTERCAMBIOSVIRTUALES.ORG

